# SPECIAL — AI-enabled web app

## Deploy with GitHub + Netlify
1. Upload all files and folders in this repository to a GitHub repository (do not upload the ZIP as a single file).
2. In Netlify, choose **Add new project → Import an existing project**, connect GitHub, and select this repository.
3. Netlify reads `netlify.toml`; publish directory is `.` and serverless functions are in `netlify/functions`.
4. In Netlify site environment variables, set `GEMINI_API_KEY` for **Production** and **Functions**. Never put the key in website files or GitHub.
5. Trigger a new deploy. After deployment, `/.netlify/functions/chat` should respond with `Method not allowed` to a browser GET request (that confirms the function exists; chat uses POST).

## Notes
- The browser stores chat history locally on the device. There are no user accounts or cloud-synced chats in this prototype.
- Messages are sent to Google's Gemini API to generate replies. Avoid entering highly sensitive personal information.
- Before inviting the public, add a privacy policy, terms, abuse reporting, rate limits, moderation, and appropriate age controls. SPECIAL is not a therapist or emergency service.
